import React from 'react';
import logo from '../assets/images/logo.png';
import {
  Container,
  Typography,
  Paper,
  Box,
  CssBaseline,
  ThemeProvider,
  IconButton,
} from '@mui/material';
import DataDisplayPage from './DataDisplayPage';
import lightBlueTheme from './theme';

function WelcomePage() {
  return (
    <ThemeProvider theme={lightBlueTheme}>
      <CssBaseline />
      <Container maxWidth="lg"> {/* Changed maxWidth to "lg" (large) */}
        <Paper elevation={3}>
          <Box sx={{ display: 'flex', alignItems: 'center', p: 3, mb: 3 }}>
            <IconButton disableRipple sx={{ p: 0, mr: 2 }}>
              <img src={logo} alt="Lookup Data Explorer Logo" style={{ height: 160 }} />
            </IconButton>
            <Box sx={{ display: 'flex', flexDirection: 'column' }}>
              <Typography variant="h5" component="h1" color="primary" sx={{ mb: 0.5 }}>
                GLB Lookup Informtion
              </Typography>
              <Typography variant="subtitle1" color="textSecondary">
                Please select the look up categories, specific information will be returned.
              </Typography>
            </Box>
          </Box>
          <Box sx={{ p: 3 }}>
            <Typography variant="h6" component="h2" sx={{ mb: 1 }}>
              Category Information
            </Typography>
            <DataDisplayPage />
          </Box>
        </Paper>
        <Box sx={{ mt: 4, textAlign: 'center', color: 'text.secondary', fontSize: '0.8em' }}>
          <Typography variant="body2" color="textSecondary">
            © 2025 My Application
          </Typography>
        </Box>
      </Container>
    </ThemeProvider>
  );
}

export default WelcomePage;