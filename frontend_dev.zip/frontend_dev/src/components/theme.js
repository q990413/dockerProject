// src/theme.js (or src/components/theme.js if you moved it)
import { createTheme } from '@mui/material/styles';

const lightBlueTheme = createTheme({
  palette: {
    primary: {
      main: '#81D4FA', // 밝은 파란색
    },
    secondary: {
      main: '#E1F5FE', // 더 밝은 파란색
    },
    background: {
      default: '#F0F8FF', // 옅은 하늘색
      paper: '#FFFFFF', // 흰색 (약간의 투명도 적용 가능)
    },
    text: {
      primary: '#333333',
      secondary: '#777777',
    },
  },
  typography: {
    fontFamily: 'Roboto, sans-serif',
    h1: {
      fontWeight: 500,
      fontSize: '2.5rem',
      marginBottom: '1rem',
    },
    h6: {
      fontWeight: 400,
      fontSize: '1rem',
      marginBottom: '0.5rem',
      color: '#777777',
    },
    body1: {
      lineHeight: 1.8,
    },
  },
  components: {
    MuiPaper: {
      styleOverrides: {
        root: {
          padding: '2rem',
          borderRadius: '8px',
          boxShadow: '0px 2px 10px rgba(0, 0, 0, 0.1)', // 은은한 그림자
        },
      },
    },
    MuiContainer: {
      styleOverrides: {
        root: {
          paddingTop: '2rem',
          paddingBottom: '4rem',
        },
      },
    },
    MuiLink: {
      styleOverrides: {
        root: {
          color: '#81D4FA',
          textDecoration: 'none',
          '&:hover': {
            textDecoration: 'underline',
          },
        },
      },
    },
  },
});

// Add this line to export the theme
export default lightBlueTheme;