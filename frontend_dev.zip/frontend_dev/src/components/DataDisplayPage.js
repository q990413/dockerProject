import React, { useState, useEffect } from 'react';
import { fetchLookupTypes, fetchLookupData } from '../api';
import './DataGridDisplay.css'; // Import CSS for styling

function DataGridDisplay() {
  const [lookupTypes, setLookupTypes] = useState([]);
  const [selectedType, setSelectedType] = useState('');
  const [data, setData] = useState([]);
  const [loadingTypes, setLoadingTypes] = useState(true);
  const [errorTypes, setErrorTypes] = useState(null);
  const [loadingData, setLoadingData] = useState(false);
  const [dataError, setDataError] = useState(null);

  useEffect(() => {
    const fetchTypes = async () => {
      try {
        const types = await fetchLookupTypes();
        setLookupTypes(types);
      } catch (err) {
        setErrorTypes(err.message);
      } finally {
        setLoadingTypes(false);
      }
    };

    fetchTypes();
  }, []);

  useEffect(() => {
    const fetchDataByType = async (type) => {
      setLoadingData(true);
      setDataError(null);
      try {
        const result = await fetchLookupData(type);
        setData(result);
      } catch (err) {
        setDataError(err.message);
      } finally {
        setLoadingData(false);
      }
    };

    if (selectedType) {
      fetchDataByType(selectedType);
    } else {
      setData([]);
    }
  }, [selectedType]);

  const handleTypeChange = (event) => {
    setSelectedType(event.target.value);
  };

  if (loadingTypes) return <div>Loading lookup types...</div>;
  if (errorTypes) return <div>Error loading lookup types: {errorTypes}</div>;

  return (
    <div>
      <h2>Lookup Data</h2>
      <div>
        <label htmlFor="lookupType">Select Lookup Type:</label>
        <select id="lookupType" value={selectedType} onChange={handleTypeChange}>
  <option value="">-- Select --</option>
  {lookupTypes.map((type) => (
    <option key={type} value={type}>{type}</option>
  ))}
</select>
      </div>

      {loadingData && <div>Loading data...</div>}
      {dataError && <div>Error loading data: {dataError}</div>}

      {data.length > 0 && (
        <div>
          <h3>Data for: {selectedType}</h3>
          <div className="data-grid-container">
            <div className="grid-header">
              <div className="grid-column">Lookup ID</div> {/* Changed Header */}
              <div className="grid-column">Description</div>
              <div className="grid-column">Lookup Code</div>
              {/* Add more headers based on your data */}
            </div>
            {data.map((item) => (
              <div key={item.LookupID} className="grid-row">
                <div className="grid-column">{item.LookupID}</div> {/* Changed Data */}
                <div className="grid-column">{item.Description}</div>
                <div className="grid-column">{item.LookupCode}</div>
                {/* Add more data cells based on your data */}
              </div>
            ))}
          </div>
        </div>
      )}

      {selectedType && data.length === 0 && !loadingData && !dataError && (
        <div>No data found for the selected lookup type.</div>
      )}
    </div>
  );
}

export default DataGridDisplay;