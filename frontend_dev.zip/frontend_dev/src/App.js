import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import WelcomePage from './components/WelcomePage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<WelcomePage />} /> {/* 기본 경로에 WelcomePage */}
        
        {/* 다른 라우트 추가 */}
      </Routes>
    </Router>
  );
}
export default App;