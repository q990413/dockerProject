// src/api.js

const API_BASE_URL = 'http://localhost:3000';

export const fetchLookupTypes = async () => {
  try {
    const response = await fetch(`${API_BASE_URL}/lookup/lookup_Detail`);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("API 호출 실패 (Lookup Types):", error);
    throw error;
  }
};

export const fetchLookupData = async (lookupType) => {
  try {
    let url = `${API_BASE_URL}/lookup/lookupDBs`;
    if (lookupType) {
      url = `${API_BASE_URL}/lookup/lookup_Detail?LookupType=${lookupType}`;
    }
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    console.error("API 호출 실패 (Lookup Data):", error);
    throw error;
  }
};