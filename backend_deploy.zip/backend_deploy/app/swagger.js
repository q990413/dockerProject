const swaggerJsDoc = require("swagger-jsdoc");
const swaggerUi = require("swagger-ui-express");

const swaggerOptions = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "Lookup API",
      version: "1.0.0",
      description: "API to retrieve Lookup data",
    },
    servers: [{ url: "http://localhost:3000/lookup" }],
  },
  apis: ["./routes/lookupRoutes.js"], // Adjust this path to match your route files
};

const swaggerDocs = swaggerJsDoc(swaggerOptions);

module.exports = { swaggerDocs, swaggerUi };
