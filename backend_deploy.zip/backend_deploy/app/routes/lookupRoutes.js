const express = require("express");
const sql = require("mssql");

const router = express.Router();


router.get("/lookupDBs", async (req, res) => {
    try {
      const result = await sql.query(`
        SELECT LookupID, LookupSrc, LookupType, LookupCode, Description 
        FROM dbo.glb_Lookups
      `);
      res.json(result.recordset);
    } catch (error) {
      console.error("Database error:", error);
      res.status(500).json({ error: "Database query failed", details: error.message });
    }
  });


router.get("/lookup_Detail", async (req, res) => {
  try {
    const { LookupSrc, LookupType, LookupCode } = req.query;
    let query = "SELECT LookupID, LookupCode, Description FROM dbo.glb_Lookups WHERE 1=1";

    if (LookupSrc) query += ` AND LookupSrc = '${LookupSrc}'`;
    if (LookupType) query += ` AND LookupType = '${LookupType}'`;
    if (LookupCode) query += ` AND LookupCode = '${LookupCode}'`;

    const result = await sql.query(query);
    res.json(result.recordset);
  } catch (error) {
    res.status(500).json({ error: "Database query failed" });
  }



  
})
router.get("/lookuptypes", async (req, res) => {
  try {
    const query = "SELECT DISTINCT LookupType FROM dbo.glb_Lookups"; // Get distinct LookupType values
    const result = await sql.query(query);
    // Extract the LookupType values from the recordset (array of objects)
    const lookupTypes = result.recordset.map(row => row.LookupType);
    res.json(lookupTypes);
  } catch (error) {
    console.error("Error fetching lookup types:", error);
    res.status(500).json({ error: "Failed to fetch lookup types from DB" });
  }
});;

module.exports = router;
