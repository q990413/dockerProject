const express = require("express");
const lookupRoutes = require("./routes/lookupRoutes.js");
const sql = require("mssql"); // Import mssql
const fs = require('fs').promises; // Use the promises API for cleaner async/await
const { parseString } = require('xml2js');

const app = express();
const port = process.env.PORT || 3000;

const cors = require('cors');
app.use(cors());


// Mount lookupRoutes at /lookup
app.use("/lookup", lookupRoutes);


async function initializeDatabase() {
    const dbConfigFromXml = await loadDbConfigFromXml('./dbConfig.xml'); //

    if (dbConfigFromXml) {
        sql.connect(dbConfigFromXml)
            .then(() => console.log("Connected to SQL Server"))
            .catch((err) => console.error("Database Connection Failed:", err));
    } else {
        console.error("Failed to load database configuration from XML. Exiting.");
        process.exit(1);
    }
}
async function loadDbConfigFromXml(filePath) {
    try {
        const xmlData = await fs.readFile(filePath, 'utf-8');
        console.log('XML Data Read:', xmlData);

        return new Promise((resolve, reject) => {
            parseString(xmlData, (err, result) => {
                if (err) {
                    console.error('XML Parsing Error:', err);
                    reject(err);
                    return;
                }
                console.log('Raw Parsed XML (Promise):', JSON.stringify(result, null, 2));

                const config = result && result.databaseConfig;
                console.log('Extracted databaseConfig (Promise):', JSON.stringify(config, null, 2));

                if (!config) {
                    console.error("Error: 'databaseConfig' element not found in XML (Promise).");
                    resolve(null); // Resolve with null if config is missing
                    return;
                }

                resolve({
                    user: config.user && config.user[0] ? config.user[0] : null,
                    password: config.password && config.password[0] ? config.password[0] : null,
                    server: config.server && config.server[0] ? config.server[0] : null,
                    database: config.database && config.database[0] ? config.database[0] : null,
                    options: config.options && config.options[0] ? {
                        encrypt: config.options[0].encrypt && config.options[0].encrypt[0] === 'true',
                        trustServerCertificate: config.options[0].trustServerCertificate && config.options[0].trustServerCertificate[0] === 'true',
                    } : {},
                });
            });
        });
    } catch (err) {
        console.error("Error loading XML file:", err);
        return null;
    }
}

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
    initializeDatabase(); // Initialize database connection after the server starts listening
});

